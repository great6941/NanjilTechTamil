முகப்பு:

   இந்த மென்பொருள் பதிப்பானது "விண்டோஸ் 10 இயங்குதளத்தில் தேவையற்ற உள்ளீட்டை நீக்கும் செயலி" என்பதாகும்.

   இது பல்வேறு இலவச மென்பொருட்களின் ஒன்றுசேர்க்கப்பட்ட தொகுப்பு ஆகும். 

   இவை யாவும் நாங்கள் சேவை கொடுக்கும் ஒவ்வொரு கணினியிலும் பயன்படுத்தும் மென்பொருள். 
   
   
   

மாற்றங்கள் நீக்கம் Restore: 

   இந்த பதிப்பின் மாற்றங்களை நீக்க, "Restore" என்ற பகுதியில் உள்ள பதிவினை powershell இல் இயக்கவும்.


அம்சங்கள்:

- Dark Mode
- One Command to launch and run
- Chocolatey Install
- O&O Shutup10 CFG and Run
- Added Install Programs
- Added Debloat Microsoft Store Apps
- Full GUI Implementation

எனது உள்ளீடு:

தமிழ் விளக்கம் மற்றும் மொழி பெயர்ப்பு.

#
How To:

YouTube: https://youtube.com/naveenresearchtamil

#
This project is a fork, Translated with How-To guide | All credits goes to respective opensource script contributors.
